<?php
/*
[database]
servername= "dashboarddb"
username= "user"
password = "Asymmetrica2023"
dbname = "datatable"

[application]
target_dir="POIManager/files/"
language_file="languages.csv"

[poi]
poi_template_column="name,abbreviation,descriptionShort,descriptionLong,phone,fax,url,email,refPerson,secondPhone,secondFax,secondEmail,secondCivicNumber,secondStreetAddress,notes,timetable,photo,other1,other2,other3,postalcode,province,city,streetAddress,civicNumber,latitude,longitude"
poi_datatypes="string,string,string,string,string,string,URL,email,string,string,string,email,string,string,string,string,URL,string,string,string,string,string,string,string,string,float,float"
cell_special_characters="?,|"

[api]
ownershipApiUrl = "https://dashboard /ownership-api/v1/register/?"
valueTypeValueUnitApiUrl="https://dashboard /iot-directory/api/device.php/?"
valueTypeValueUnitApiUrlTest="https://dashboard /processloader/api/"
processLoaderURI= "https://dashboard /processloader/api/"
ownershipLimitApiUrl="https://dashboard /ownership-api/v1/limits?type=PoiTableID&accessToken="
ownershipListApiUrl="https://dashboard /ownership-api/v1/list/?type=PoiTableID&accessToken="
ownershipDeleteApiUrl="https://dashboard /ownership-api/v1/delete/?type=PoiTableID&"
processLoaderNatureURI="https://dashboard /processloader/api/dictionary/?type=subnature"
processLoaderValueUnitURI="https://dashboard /processloader/api/dictionary/?type=value_unit"
processLoaderContextBrokerURI="https://dashboard /iot-directory/api/contextbroker.php/?action=get_all_contextbroker&nodered"
valueTypeValueUnitAction="get_param_values"
valueTypeValueUnitNodered="1"
elementType = "PoiTableID"
elementUrl = ""
elementName = "PoiTableID"
base_suri="http://www.disit.org/km4city/resource/poi/"
uploaderUserUrl="https://dashboard /auth/realms/master/protocol/openid-connect/userinfo"
delegationUrl="https://dashboard /datamanager/api/v1/username/"
locationUrl="https://dashboard /ServiceMap/api/v1/location/?"
